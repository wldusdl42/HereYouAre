package com.spring.dao;

import com.spring.dto.Bmember;

public interface BmemberDAO5 {

	Bmember adminCheck(String email);

}
