package com.spring.dto;

import java.util.List;

public class heartListFromView {
	
	private List<Integer> join;

	public List<Integer> getJoin() {
		return join;
	}

	public void setJoin(List<Integer> join) {
		this.join = join;
	}
}
