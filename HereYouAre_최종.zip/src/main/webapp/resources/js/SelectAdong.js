
            function selected_adong() 
            {
                var dongValue = $("#out").val();                
                $("#getAdongCd").attr("value",dongValue); 
                document.getElementById('form').submit();
                
                alert("\n로딩 중 입니다.\n\n잠시만 기다려 주세요.\n\nꉂꉂ(ᵔᗜᵔ*)ꉂꉂ(ᵔᗜᵔ*)ꉂꉂ(ᵔᗜᵔ*)");
            }
                
